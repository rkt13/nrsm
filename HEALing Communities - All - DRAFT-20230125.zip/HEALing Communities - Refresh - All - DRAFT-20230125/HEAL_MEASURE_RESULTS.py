import numpy as np
import pandas as pd
import sys
import datetime

SUPPRESSION_THRESHOLD = 30

def summarize_measure(df, strat_col, filters = None, timeframe = "YEAR"):
    #Summarize HEAL export dataframe by selected stratification column & timeframe and apply filters

    filtered = df.loc[(df[list(filters)] == pd.Series(filters)).all(axis = 1)].copy()
    
    filtered["Stratification"] = '"' + strat_col + '":"' + filtered[strat_col] + '"'
    
    if timeframe == "YEAR":
        filtered["YEAR"] = filtered["YEAR"].str[2:]
        filtered["MONTH"] = "all"
        
    elif timeframe == "MONTH":
        filtered["YEAR"] = filtered["MONTH"].str[:4]
        filtered["MONTH"] = filtered["MONTH"].str[5:7]
    
    result = filtered.groupby(['REPORTER_ID', 'MSR_ID', 'YEAR', 'MONTH', 'Stratification']).sum()[["NUM", "DEN"]].reset_index()
    result['Suppressed'] = np.where(result['DEN'] < SUPPRESSION_THRESHOLD, 1, 0)
    
    result = result.rename(columns = {"REPORTER_ID": "ReporterID",
                   "MSR_ID": "MeasureID",
                   "YEAR": "Year",
                   "MONTH": "Month",
                   "NUM": "Numerator",
                   "DEN": "Denominator"})
    return result


def HEAL_export(df, config, timeframe = "YEAR"):
    #Run measure summaries for all measures and all columns
    
    #Create config/filters
    filters = []
    for msr in config.MSR_ID.unique():
        _ = config[config.MSR_ID == msr]
    
        d = {}
        d["MSR_ID"] = msr

        for index, row in _.iterrows():
            if pd.notnull(row["COL"]):
                d[row["COL"]] = row["VAL"]
    
        filters.append(d)
    
    #Summarize for each measure
    results = []
    
    if timeframe == "YEAR":
        strat_cols = ["MBR_SEX_CD", "MBR_AGE_GROUP", "MBR_RACE", "HEWG"]
    elif timeframe == "MONTH":
        strat_cols = ["HEWG"]
        
    for f in filters:
        for col in strat_cols:
            results.append(summarize_measure(df, col, f, timeframe))
    
    result = pd.concat(results)
    return result



if len(sys.argv) < 4:
    print("Error: Usage HEAL_MEASURE_RESULTS.py <config_file> <year_file> <month_file>")
    exit(-1)

#Read Arguments
config_file = sys.argv[1]
year_file = sys.argv[2]
month_file = sys.argv[3]

#Import config & export files
config = pd.read_csv(config_file, sep = ",", header = 0)
df_year = pd.read_csv(year_file, sep = ',', header = 0)
df_month = pd.read_csv(month_file, sep = ',', header = 0)

#Summarize yearly and monthly exports according to HEAL data model
year_results = HEAL_export(df_year, config, "YEAR")
month_results = HEAL_export(df_month, config, "MONTH")

#Concatenate results and write to file 
HEAL_results = pd.concat([year_results, month_results])

today = datetime.datetime.now()
HEAL_results.to_csv("HEAL_MSR_RESULTS_{}.csv".format(today.strftime('%Y-%m-%d')), index = False)


